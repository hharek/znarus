_packjs.jquery_ui = 
{
	/**
	 * Инициализация
	 */
	init: function ()
	{
		$("head").append
		(
			'<link href="packjs/jquery_ui/jquery-ui.css" rel="stylesheet">' +
			'<script src="packjs/jquery_ui/jquery-ui.js"></script>' 
		);
	}
};