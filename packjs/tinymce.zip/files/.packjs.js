_packjs.tinymce = 
{
	/**
	 * Инициализация
	 */
	init: function ()
	{
		$("head").append('<script src="packjs/tinymce/tinymce.min.js"></script>');
	},
	
	/**
	 * Создание
	 */
	create: function (param)
	{
		var path;
		if (param.id !== undefined)
		{
			path = "textarea#" + param.id;
		}
		else if (param.name !== undefined)
		{
			path = "textarea[name=" + param.name + "]";
		}
		
		tinyMCE.init
		({
			language : "ru",
			selector: path,
			theme: "modern",
			height: 400,
			fontsize_formats: "8px 10px 12px 13px 14px 16px 18px 20px",
			plugins: ["code","image","media","table","link","anchor","fullscreen"],
			content_css: _settings.css_default,
			toolbar: "undo redo | bold italic underline | fontsizeselect | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | inserttable | link unlink anchor | image | link | fullscreen ",
			relative_urls : false
		});
	},
	
	/**
	 * Освобождаем ресурсы
	 */
	clean: function ()
	{
		tinyMCE.remove();
	},
	
	/**
	 * Сохранить данные в html-элементе
	 */
	save: function ()
	{
		tinyMCE.triggerSave();
	},
	
	/**
	 * Назначить данные из html-элемента
	 */
	set: function ()
	{
		for(var i = 0; i < tinyMCE.editors.length; i ++)
		{
			var value = $(tinyMCE.editors[i].targetElm).val();
			tinyMCE.editors[i].setContent(value);
		}
	}
};